from PIL import Image


outImg  = Image.new( 'RGB', (128,128), "white") # create a new black image
pixels= outImg.load()

for i in xrange(0,(128*128)):
	zeros=4
	for j in xrange(1,5):
		if (10**j)<=i:
			zeros-=1
	filename="frame"
	for j in xrange(0,zeros):
		filename+="0"
	filename+=str(i)
	filename+=".png"
	im = Image.open(filename) #Can be many different formats.
	pix = im.load()
	x,y= im.size #Get the width and hight of the image for iterating over
	print i
        rs,gs,bs=(0,0,0)
	for row in xrange(0,150):
		for col in xrange(0,150):
			if (pix[row,col]==(255,255,255,255)): 
				continue #Ignore black pixels
			else:
				rs+= pix[row,col][0]
				gs+=pix[row,col][1]
				bs+=pix[row,col][2] #Get the RGBA Value of the a pixel of an image
	 # Set the RGBA Value of the image (tuple)
	pixels[i/128,i % 128]= (255*rs/(rs+bs+gs),(255*gs/(rs+gs+bs)),(255*bs/(rs+gs+bs)))

outImg.show()
