<?php if(!defined('simple_cms')) exit(); ?>
<html>
	<head>	
		<meta charset="utf-8">
		<title>simple cms</title>
	</head>
	<body>
		<center>
