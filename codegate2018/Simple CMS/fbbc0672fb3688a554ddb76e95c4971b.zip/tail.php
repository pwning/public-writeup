<?php if(!defined('simple_cms')) exit(); ?>
		
		</center>
	</body>
</html>