<?php if(!defined('simple_cms')) exit(); ?>
			<a href='?act=board&mid=default'>board</a> | <a href='?act=user&mid=myinfo'>myinfo</a> | <a href='?act=user&mid=logout'>logout</a>